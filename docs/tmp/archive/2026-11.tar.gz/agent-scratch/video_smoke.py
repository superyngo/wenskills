"""Smoke test: video-mode build_ydl_opts against a real YouTube video."""
import importlib.util
import shutil
import sys

spec = importlib.util.spec_from_file_location(
    "dl", "skills/yt-channel-dl/scripts/download_channel.py"
)
dl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(dl)

opts = dl.build_ydl_opts(
    "/tmp/ytdl-video-test2", "mp4", shutil.which("ffmpeg"),
    10 * 1024 * 1024, "Mozilla/5.0", media_type="video",
)
print("format:", opts["format"])
print("merge_output_format:", opts.get("merge_output_format"))

import yt_dlp

with yt_dlp.YoutubeDL(opts) as ydl:
    ydl.download(["https://www.youtube.com/watch?v=jNQXAC9IVRw"])
print("OK", file=sys.stderr)
