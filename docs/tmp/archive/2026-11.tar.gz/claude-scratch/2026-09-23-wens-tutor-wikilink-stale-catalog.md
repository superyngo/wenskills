# wens-tutor: wikilink jumps land in the wrong place (2026-09-23)

Status: FIXED and committed (A + B + fid fix + code-fence headings + docs/tmp exclusion). Verified on the real root with port 8799.
Open item: 11 tests in tests/ still hard-code corpus counts, and the corpus has since grown, so they fail. This failure existed before the fix and is not handled yet.

- Symptom: in 機器學習/筆記.md, clicking [[#降維技術補充：SVD 與 LDA]] jumps to the wrong place. Obsidian gets it right.
- Evidence:
  - The live server's `/api/file` returns line_start=146 for that section. The file on disk has the heading at line 431.
  - The server started at 2026-09-22 14:38. 筆記.md was modified at 2026-09-23 09:09.
  - The offline pipeline is correct: markdown-it data-line = 431 and parse_sections = 431.
- Root cause: `state.open_root` builds the catalog (`cat.section`) once, in memory, when the process starts (ADR 0001). `/raw` serves the file fresh from disk, but `meta.sections` comes from that start-up snapshot. After the Markdown is edited, `wireWikilinks`/`buildToc` scroll to the old line numbers.
- Side finding: `parse_sections` also counts `#` lines inside ``` fences as headings. It finds 190 sections; markdown-it finds 158 headings. The TOC gets fake entries, and a duplicate title could make a wikilink jump to the wrong one.
- Fix options: see the report in the session transcript. (A) resolve wikilinks against the rendered DOM headings, (B) have /api/file re-parse the file fresh, (C) rebuild the catalog when files change.
- User chose A+B (still needs a final go-ahead before code changes). Code-fence heading fix: not answered yet.

## Bug 2: `serve` crashes on start with `UNIQUE constraint failed: file.fid` (reproduced on a DB copy)
- The trigger is a new file, 機器學習/docs/tmp/claude-scratch/筆記.orig.md (2026-09-23 09:04). It is a near-copy of 筆記.md, and `material_files` sorts it first.
- In `state.open_root.fid_for`, the new path is not in `known`. It then tries rename matching: jaccard ≥ 0.6 against 機器學習/筆記.md, which is excluded only once *seen*, and it has not been seen yet. So the new file steals fid 4be85019af4a.
- When 筆記.md is scanned next, `known.get(rel)` still returns that same fid. The second INSERT into cat.file then fails.
- Root cause: the rename heuristic does not check that the old relpath is gone from disk.
- The real DB is intact: the uncommitted UPDATE was rolled back, and file_id still maps 4be85019af4a → 機器學習/筆記.md.
- Planned fix: only treat a known row as a rename candidate if its relpath is absent from the current `material_files` set. Add a regression test in tests/.
- Side finding: docs/tmp/claude-scratch/*.md inside the Materials Root are indexed as Courses. Should they be excluded?
