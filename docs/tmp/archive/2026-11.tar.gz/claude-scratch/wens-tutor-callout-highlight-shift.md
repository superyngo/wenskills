# wens-tutor: highlight inside hidden-answer callout shifts 7 chars early

Status: diagnosed, awaiting user approval (no code changed).

Symptom: in 中級_科目3_考古題_依章節.md, highlighting text inside a folded `> [!success]- 答案：X`
callout renders ~7 chars to the left of the selection. Normal paragraphs are fine.

Root cause (hypothesis, from code reading):
- `web/app/render.js` callout rule: the paragraph inside the callout keeps `map[0]` equal to the
  `[!type]` line, so `<div.callout data-line=N>` and its inner `<p data-line=N>` share a data-line.
- `selectionToOffset` walks up from the selection to the nearest `[data-line]` -> the `<p>`; offsets are
  relative to the `<p>`.
- `reader.js` btnApply / btnClear and `render.anchor` resolve the block with
  `blocks(doc).find(b => data-line === block_line)` -> first in document order -> the callout div.
- Callout textContent before the `<p>` = reveal button (2: 顯示/隱藏) + title `答案：X` (4) + "\n" (1) = 7.
- Offset relative to `<p>` applied to callout => mark lands 7 chars early.

Planned fix: make the block lookup unambiguous (e.g. selectionToOffset returns the block element /
disambiguate shared data-line), and keep stored offsets compatible. Verify on the real served site.
