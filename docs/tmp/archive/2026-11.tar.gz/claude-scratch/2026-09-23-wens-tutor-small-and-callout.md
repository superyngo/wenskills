# wens-tutor: `<small>` and Obsidian callouts not rendered (2026-09-23)

Status: FIXED and committed. Callouts are merged into the reader answer toggle, and state persists.
Open item: in other banks, plain-text "答案：B" paragraphs sit directly in <p>, where visibility cannot hide them. That existing CSS bug is not handled yet.

- Symptoms (題庫/中級_科目1_考古題_依章節.md, 中級_科目3_考古題_依章節.md):
  1. In every question heading, `<small>114年第二次｜情感分析</small>` shows up as literal tag text.
  2. The `> [!success]- 答案：B` block (plus its explanation) always shows expanded, with `[!success]-` printed as literal text. Obsidian renders this as a folded callout.
- Root cause (web/app/render.js):
  1. Line 2, `markdownit({ html: false })`, escapes all raw HTML, `<small>` included.
  2. There is no Obsidian callout syntax handling, so `> [!type]-` renders as an ordinary blockquote.
- Same root cause elsewhere: `<br/>` inside the table cells of AI應用規劃師/筆記.md (lines 203-205) also shows as literal text.
- Proposed fix:
  - Keep `html: false`. Add a small whitelist inline rule for small/br/sub/sup/kbd/mark/u, and ignore any tag that has attributes.
  - Add a core rule that rewrites a blockquote whose first line is `[!type][-+]? title` into `<details>/<summary>`. `-` means folded, `+` means expanded, and no marker means a non-foldable box. Keep the data-line stamping.
  - If a wikilink or annotation target sits inside a folded callout, open that callout first.
